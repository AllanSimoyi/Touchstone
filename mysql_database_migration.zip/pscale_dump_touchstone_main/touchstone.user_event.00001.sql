INSERT INTO `user_event`(`id`,`createdAt`,`updatedAt`,`recordId`,`userId`,`details`,`kind`) VALUES
(1,"2023-08-07 14:52:13.513","2023-08-07 14:52:13.513",22,1,"{\"accessLevel\":\"Level 1\",\"username\":\"Aidan\"}","Create"),
(2,"2023-08-07 15:17:06.442","2023-08-07 15:17:06.442",23,1,"{\"accessLevel\":\"Level 1\",\"username\":\"Muchie\"}","Create"),
(3,"2023-08-07 15:19:37.676","2023-08-07 15:19:37.676",24,1,"{\"accessLevel\":\"Level 1\",\"username\":\"Jackie\"}","Create");
