INSERT INTO `area_event`(`id`,`createdAt`,`updatedAt`,`areaId`,`userId`,`details`,`kind`) VALUES
(2,"2023-08-07 14:39:05.577","2023-08-07 14:39:05.577",139,1,"{\"name\":\"Type\",\"createdAt\":\"2023-08-07\",\"updatedAt\":\"2023-08-07\"}","Update");
